package com.example.qlique;

public class AppConfig {
    public static String CLIENT_ID = "2206280576174843";
    public static String CLIENT_SECRET = "d54beb4a6eef6d00995fd56008917c2c";
    public static String CALLBACK_URL = "https://qlique-fbd4b.firebaseapp.com/__/auth/handler";

}
